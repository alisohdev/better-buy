# Iranian Hosted Commerce Platform — Foundation Package

**Status:** Planning baseline, not an implemented application.

This package captures the product, architecture, first milestone, and a narrowly bounded first Codex task for a hosted Iranian store builder.

## Read in this order

1. [`docs/product/VISION.md`](docs/product/VISION.md) — who it is for and how we will evaluate success.
2. [`docs/milestones/M0.md`](docs/milestones/M0.md) — first working product, scope, acceptance tests, and implementation slices.
3. [`docs/adr/`](docs/adr/) — decisions and explicit tradeoffs.
4. [`docs/research/COMPETITOR-AUDIT.md`](docs/research/COMPETITOR-AUDIT.md) — how to validate differentiation.
5. [`AGENTS.md`](AGENTS.md) — agent conventions and boundaries.
6. [`CODEX-KICKOFF.md`](CODEX-KICKOFF.md) — ready-to-paste first implementation prompt.

## Decisions currently accepted

- Go API, initially a **modular monolith** (`chi`/`net/http`, `pgx`, `sqlc`).
- PostgreSQL as the authoritative database.
- React + TypeScript admin, Bun for JS package/build/test tooling.
- React SSR storefront renderer, with a deployment/runtime spike before a permanent choice.
- Shared-DB store tenancy with authorization enforced server-side on every protected operation.
- Users and stores related through memberships; first UI primarily targets sole owners.
- One section-based theme; hosted subdomains first.
- M0 ends at a **published, publicly viewable storefront**, not checkout.

## Intentionally unresolved

- Product/brand name, registered domain, pricing model.
- Final storefront SSR runtime and deployment boundary.
- Initial niche and measurable differentiation versus established Iranian store builders.
- Payment providers, merchant requirements, shipping and subscriptions: later milestones.

## Guardrail

The platform may have a large ambition, but **M0 must remain small**. No microservices, app marketplace, dynamic plugins, drag-and-drop visual builder, or complex multi-warehouse inventory in this milestone.
