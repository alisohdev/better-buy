# Product Vision — Hosted Store Builder for Iran

**Status:** Hypotheses requiring user/competitor validation.

## Product promise

Help an independent Iranian merchant create a beautiful, mobile-first, Persian storefront, add products, publish it on a shareable link, and eventually accept orders—with minimal technical work.

**North-star experience for M0:** A new merchant signs up, creates a named store, adds and publishes one product, and opens the public product page. We aim for a few minutes of active work; the time target must be validated, not assumed.

## Initial customer hypothesis

Small independent fashion, accessories, handmade-goods, and creator-led brands that currently sell through social channels but want a dedicated storefront. Focus on one initial niche after observing real merchants; do not market simultaneously to every vertical.

## Value hypotheses to test

1. **Low onboarding friction:** Faster path from account creation to a useful live storefront than alternatives.
2. **Quality out of the box:** A single excellent mobile-first storefront that needs little customization.
3. **Localized defaults:** RTL Persian design, correct money-unit communication, and Iran-appropriate hosting/billing as those features ship.
4. **Trust:** Predictable publication, clear merchant ownership, and later reliable payment and order handling.

None of these are established competitive advantages yet. Interview/observe merchants and run timed competitor trials.

## Non-goals for first milestone

- Replacing all of Shopify or leading Iranian incumbents.
- Checkout, payments, refunds, shipping or fulfillment.
- A marketplace, apps/extensions, multiple themes, agencies, complex analytics.
- AI-assisted site generation as a prerequisite for publishing.

## Business model — unvalidated

Hosted subscription billing is the likely direction; trial/free-plan design and pricing remain experiments. Do not implement monetization in M0.

## Signals to track

- % of new accounts that create a store.
- % of created stores that publish at least one product.
- Median time from signup to publicly viewable product.
- % of first-week stores that return and update a product.
- Failed publish attempts, rendering failures, tenant-isolation defects.
- After payments exist: trial-to-paid, store retention, active order volume, support costs.

## Commercial validation parallel to M0

Observe at least three merchants attempting similar tasks in existing store builders and in our prototype. Record elapsed time, friction, moments of confusion, and what they would actually pay to improve. Keep evidence separate from assumptions.
