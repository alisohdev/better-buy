# ADR 0001 — Go Modular Monolith and React Interfaces

**Status:** Accepted as initial direction. **Date:** 2026-10-11.

## Context

We seek long-term extensibility while a small team must ship quickly. Technology and module decisions should not force premature infrastructure complexity.

## Decision

- Core API: Go, standard `net/http` with `chi`, PostgreSQL using `pgx` + `sqlc`.
- Architecture: modular monolith; domains organize ownership and expose clear application operations, compiled as a single core application.
- Merchant admin: React + TypeScript + Vite + Tailwind/shadcn/ui; Bun for front-end package/build/test tooling.
- Storefront: React SSR process, initially separated operationally from the Go API; runtime chosen after M0 SSR spike.
- Contracts: OpenAPI, generated TS client; no assumed cross-language type sharing.
- Jobs: PostgreSQL-backed where actually needed; no Redis/broker/microservices in M0.

## Reasoning

Go brings operational simplicity and durable backend infrastructure. TypeScript optimizes interface development. One core process avoids distributed transaction and deployment overhead before scale requires it.

## Consequences

- Business modules should not reach directly into each other's tables from unrelated handlers.
- Cross-module interactions use explicit Go interfaces/functions; avoid a custom module/plugin runtime.
- SSR runtime adds a separate deployment component; validate its operational cost during bootstrap.
- Measure before splitting processes or choosing specialized infrastructure.

## Revisit when

A proven bottleneck, isolation requirement, or team boundary makes independent deployment valuable.
