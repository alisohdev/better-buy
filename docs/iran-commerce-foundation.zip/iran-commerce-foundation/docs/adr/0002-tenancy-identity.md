# ADR 0002 — Shared PostgreSQL Tenancy + Membership Identity

**Status:** Accepted as initial direction. **Date:** 2026-10-11.

## Decision

- Store is the primary data-isolation boundary.
- The first database is shared across stores; owned business rows are associated with `store_id`.
- Users may belong to multiple stores through `store_memberships`; V1 exposes an uncomplicated owner experience.
- API determines authenticated principal from trusted session and authorizes membership for **each** protected action.
- Tenant-aware SQL, foreign keys, and integration tests enforce isolation; evaluate RLS as defense in depth when practical, not as the sole authorization control.

## Non-negotiable invariants

1. User A cannot view/change merchant B's private catalog through guessed IDs, URL changes, upload IDs, or API parameter tampering.
2. Store-scoped unique constraints and associations cannot cross stores.
3. A public storefront exposes only explicitly published, public fields.
4. Store owner cannot acquire platform-admin privileges by editing request inputs.

## Tradeoffs

Shared databases are operationally simpler but require consistent store scope and migration discipline. One database per store is intentionally deferred.

## Test requirement

For every new store-owned entity, add cross-tenant read, mutation and association tests before merging.
