# ADR 0003 — Hosted Subdomains and One React SSR Theme

**Status:** Accepted direction with one runtime spike outstanding. **Date:** 2026-10-11.

## Decision

- Each initial published store is reachable via a platform-controlled subdomain: `{slug}.shops.<our-domain>` (placeholder only; do not assume a domain is owned).
- Edge/reverse proxy forwards the trusted Host; application validates that the hostname belongs to an allowlisted platform suffix and maps it to one store.
- Public storefronts use React server-side rendering for index and product detail pages. One polished mobile-first, RTL-capable, section-based theme is shipped in M0.
- The frontend sends public API requests to the Go backend; private catalog editing remains behind merchant authorization.
- Custom domains, theme marketplace and drag/drop layout editor are deferred.

## Bootstrap spike / acceptance

Implement a production-mode SSR proof of concept and verify server-rendered HTML is returned to a plain HTTP client, real title/meta tags appear, the Host mapping is unambiguous, and a bad Host does not leak another tenant's content. Choose the renderer runtime (Bun or Node) based on this proof, not preference alone.

## Tradeoffs

Separate SSR service adds another runtime/deployment unit but keeps storefront presentation in the React ecosystem and commerce rules in Go. Do not prematurely build a generic theme execution engine.
