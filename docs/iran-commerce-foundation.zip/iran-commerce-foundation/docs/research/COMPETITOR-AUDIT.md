# Competitor and Merchant Research — Field Worksheet

**Status:** Not yet conducted for this project. This is an experiment template, not a list of findings.

## Compare actual onboarding

Candidates: Sazito, Portal, Shopfa, NexCart (verify current trial eligibility and service terms before testing).

For each platform, using equivalent product assets:

| Platform | Signup friction | Time to 1 live product | Mobile storefront quality | What blocked us? | Pricing/support facts (link/date) |
|---|---|---|---|---|---|
| Sazito | TBD | TBD | TBD | TBD | TBD |
| Portal | TBD | TBD | TBD | TBD | TBD |
| Shopfa | TBD | TBD | TBD | TBD | TBD |
| NexCart | TBD | TBD | TBD | TBD | TBD |

## Talk to merchants

Observe at least three people who might actually adopt a new store builder. Ask them to attempt a realistic publish workflow, and capture **what they do**, not only what they say. Learn their current platform/workflow, reasons for not switching, support expectations, payment-gateway constraints, and minimum trust signals.

## Evidence bar for differentiation

Write down one specific customer segment, one observed repeated problem, why incumbents don't solve it well enough, and one metric showing our flow is materially better. If no gap appears, revisit positioning *before* increasing engineering scope.
