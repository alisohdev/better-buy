# First Codex Task — Bootstrap PR (Copy/Paste)

You are the technical lead for a **new** Iranian hosted commerce platform. The business ambition is large; the implementation must remain extremely simple and testable for M0.

Read `README.md`, `AGENTS.md`, `docs/product/VISION.md`, `docs/milestones/M0.md`, and the ADRs in `docs/adr/` before making changes. Do not reinterpret future roadmaps as current requirements.

## Goal for THIS PR ONLY

Set up the working monorepo skeleton and prove all primary runtimes can build and communicate. Do not implement registration, products, payments, commerce, theme editing, or billing in this PR.

### Deliverables

1. `apps/api`: Go server with `GET /healthz` (process liveness) and `GET /readyz` (PostgreSQL connectivity), graceful shutdown, config via environment variables, and minimal structured request logging.
2. PostgreSQL migration directory and documented migration runner. Start with an empty/metadata baseline migration if no domain schema is needed yet; do not create speculative tables.
3. `apps/admin`: React/Vite/TypeScript/Tailwind application with a minimal placeholder route and successful production build, using Bun for dependency installation/scripts.
4. `apps/storefront`: minimal React SSR spike that serves **server-rendered HTML** with title/meta information, host validation, and a placeholder store result. The runtime may be Bun or Node after an explicit local check; record the choice and why. Do not build a theme engine.
5. `contracts/`: initial OpenAPI document describing health endpoints or a sensible starting contract and a reproducible TS client generation command (avoid generating unused abstractions).
6. Local bootstrap instructions (`README.md`, env example, Docker Compose for PostgreSQL only if helpful). CI for Go tests/checks and front-end typecheck/build.
7. Tests for API health/readiness and SSR Host handling; state any remaining test gaps explicitly.

### Constraints

- Keep one Go API, one React admin app, one React SSR app, one Postgres database. No Redis, Kafka, Kubernetes, plugin runtime, queue, distributed tracing infrastructure, or feature scaffolding not used by this PR.
- Security basics: never trust unvalidated Host values; avoid leaking secrets in logs; no hardcoded production credentials.
- Do not commit credentials or assume a real platform domain exists. Use placeholder configuration.
- Prefer boring code and obvious file organization.

### Work method

1. Inspect current repository state and **preserve existing work** if any. If this is a new repository, create the minimal directories.
2. Write a compact execution plan with acceptance tests.
3. Implement this PR only.
4. Run checks and tests. Report exact commands and outcomes.
5. End with a PR-style summary, key decisions, outstanding risks, and next proposed slice (**Identity + Store Membership**, not the whole platform).

### Definition of done

Clean checkout → documented local commands → PostgreSQL available → Go liveness/readiness work → admin production build succeeds → storefront returns real server-rendered HTML → basic tests + CI run.
