# Agent Guide — Commerce Platform

Read `README.md`, `docs/product/VISION.md`, `docs/milestones/M0.md`, and all accepted ADRs before proposing implementation.

## Engineering priorities

1. Preserve M0 scope and deliver one tested vertical slice at a time.
2. Correct tenancy, authorization, and publication semantics take priority over abstract extensibility.
3. Use Go modular monolith; avoid microservices, brokers, Kubernetes, generic plugin systems, and feature flags for speculative features.
4. Make API contracts explicit via OpenAPI and generate TypeScript clients. Never silently duplicate business validation in different runtimes.
5. Store financial amounts as integers with explicit currency units; no floating-point money.
6. Document all new modules' data ownership and store-isolation tests.
7. Favor readable, straightforward code and reversible decisions. Don't build a framework for the framework.

## Before each PR

- State user-visible outcome and exact acceptance tests.
- Identify out-of-scope work.
- Include migrations and local setup changes where needed.
- Execute available tests and report what passed/failed.
- Never claim a test passed without running it.

## If requirements are ambiguous

Make the smallest reversible decision consistent with the vision, note it in the PR, and do not expand M0 without explicit approval.
